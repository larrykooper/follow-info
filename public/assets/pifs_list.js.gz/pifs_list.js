$(document).ready(function() 
    { 
        $("#myPifs").tablesorter({
          sortList:[[0,1],[1,0],[2,1],[3,0],[4,0]] 
        })
    } 
); 
   
