$(document).ready(function() 
    { 
        $("#myPifs").tablesorter({headers: { 0: { sorter: true}, 1: {sorter: false},
	2: {sorter: true}, 3: {sorter: false}, 4: {sorter: true}, 5: {sorter: false} }, sortInitialOrder: "desc"}); 
    } 
); 
   
