$(document).ready(function() 
    { 
        $("#myTags").tablesorter({headers: { 0: { sorter: true}, 1: {sorter: true},
	2: {sorter: false}}}); 
    } 
); 
   
