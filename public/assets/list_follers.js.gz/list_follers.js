$(document).ready(function() 
    { 
        $("#myFollowers").tablesorter({
          sortList:[[0,1],[1,0],[2,0]] 
        })
    } 
); 
 
